
import pandas as pd
import streamlit as st

# NOTE: load_master() lives in common.sql — it joins DimCompany + FactFundamentals
# from the SQLite DB. Import it from there. This file only provides load_name_lookup().

@st.cache_data(ttl=60*60*6)
def load_name_lookup():
    return pd.read_csv("data/nse_stocks_.csv")
